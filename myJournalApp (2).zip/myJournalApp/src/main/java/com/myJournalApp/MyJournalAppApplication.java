package com.myJournalApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyJournalAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyJournalAppApplication.class, args);
	}

}
