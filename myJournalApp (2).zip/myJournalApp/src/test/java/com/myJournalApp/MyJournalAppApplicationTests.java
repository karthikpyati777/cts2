package com.myJournalApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyJournalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
